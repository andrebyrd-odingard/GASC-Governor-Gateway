package gasc.governor.integrity

import data.gasc.governor.integrity.allow_state_write
import data.gasc.governor.integrity.test_allow_state_write_success
import data.gasc.governor.integrity.test_deny_due_to_quarantined_parent
import data.gasc.governor.integrity.test_deny_due_to_unresolved_dependency
import future.keywords

test_deny_due_to_monotonicity_breach if {
	not monotonicity_preserved with input as {
		"quarantine_set_Q_current": ["Q1", "Q2"],
		"quarantine_set_Q_proposed": ["Q1"],
	}
}
