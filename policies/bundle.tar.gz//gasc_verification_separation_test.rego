package gasc.governor.verification

import data.gasc.governor.verification.allow_reintegration
import data.gasc.governor.verification.test_allow_reintegration_success
import data.gasc.governor.verification.test_deny_due_to_planner_output
import data.gasc.governor.verification.test_deny_due_to_quarantined_ancestor
import future.keywords

test_is_irreducible_on_tainted_frontier if {
	is_irreducible with input as {
		"candidate_submission": {
			"admissible_frontier_parent_ids": ["quarantined-node-A"],
		},
		"quarantine_set_Q": ["quarantined-node-A"],
	}
}
