package gasc.governor.verification

import data.gasc.governor.verification.allow_reintegration
import data.gasc.governor.verification.test_allow_reintegration_success
import data.gasc.governor.verification.test_deny_due_to_planner_output
import data.gasc.governor.verification.test_deny_due_to_quarantined_ancestor

import future.keywords

default is_irreducible := false

has_evaluative_planner_output if {
	some key in ["planner_score", "justification", "confidence_rating", "reasoning_tokens"]
	input.candidate_submission[key]
}

fresh_identity_valid if {
	input.candidate_submission.new_candidate_node_id != input.candidate_submission.target_replaced_node_id
}

frontier_contains_quarantined_ancestors if {
	some parent_id in input.candidate_submission.admissible_frontier_parent_ids
	parent_id in input.quarantine_set_Q
}

ephemeral_identity_valid if {
	input.auth_context.is_nhi == true
	input.auth_context.expires_at_epoch > input.request_timestamp_epoch
	input.auth_context.scope == "agent:state:reconstruct"
}

is_irreducible if {
	frontier_contains_quarantined_ancestors
}

is_irreducible if {
	input.verifier_execution_status == "FAILED_UNRESOLVABLE_DEPENDENCY"
}
