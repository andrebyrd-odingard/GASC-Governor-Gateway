package gasc.governor.integrity

import data.gasc.governor.integrity.allow_state_write
import data.gasc.governor.integrity.test_allow_state_write_success
import data.gasc.governor.integrity.test_deny_due_to_quarantined_parent
import data.gasc.governor.integrity.test_deny_due_to_unresolved_dependency

import future.keywords

declared_dependencies_resolved if {
	every p in input.parent_status {
		p.exists == true
	}
}

parents_are_clean if {
	not any_parent_quarantined
}

any_parent_quarantined if {
	some p in input.parent_status
	p.quarantined == true
}

monotonicity_preserved if {
	every element in input.quarantine_set_Q_current {
		element in input.quarantine_set_Q_proposed
	}
}
